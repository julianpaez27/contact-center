<?php
require_once "../models/cambiarClaveModelo.php";
require_once "../models/loginModelo.php";
session_start();
//almacenamos la variable session en $id_usuario//
$id_usuario = $_SESSION['id_usuario'];

//almacenamos las variables POST de las 2 claves en variable $clave1 y $clave2//
$clave1 = $_POST['clave1'];
$clave2 = $_POST['clave2'];

//instanciamos la clase y ejecutamos la funcion enviando las variables anteriores como parametros//
$ejecutar = new cambiarClaveModelo();
$ejecutar-> cambiarClaveModelo($clave1, $clave2, $id_usuario);


