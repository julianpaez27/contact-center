<?php
require_once ("../models/logoutModel.php");

//instanciamos la clase y ejecutamos la funcion//
$ejecutar = new logoutModel();
$ejecutar-> logout();