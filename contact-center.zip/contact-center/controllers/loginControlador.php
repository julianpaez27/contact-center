<?php
require_once ("../models/loginModelo.php");

$usuario=$_POST['usuario_log'];
$clave=$_POST['clave_log'];

$ejecutar = new loginModelo();
$ejecutar-> logear($usuario,$clave);