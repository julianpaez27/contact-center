<?php
//Se crea la clase TemplateController que contiene las funciones que llaman a cada template//
class TemplateController{
//función que llama el template del dashboard pagina de incicio//     
    public function template(){
        include "../views/template.php";        
    }
//función que llama el template de ver campañas//  
    public function ver_campana(){
        include "../views/template_ver_campana.php";        
    }
    
//función que llama el template de crear campañas//  
    public function CrearCampana(){
        include "../views/template_crear_campana.php";        
    }

//función que llama el template distribución//  
    public function distribucion(){
        include "../views/template_distribucion.php";        
    }

//función que llama el template de agregar cliente//  
    public function agregar_cliente(){
        include "../views/template_agregar_cliente.php";        
    }

//función que llama el template de ver informes//  
    public function ver_informes(){
        include "../views/template_ver_informes.php";        
    }

//función que llama el template de modificar campaña//      
    public function modificar_campana(){
        include "../views/template_modificar_campana.php";        
    }

//función que llama el template de llamadas//      
    public function llamada(){
        include "../views/template_llamada.php";        
    }

//función que llama el template de Crear Usarios//      
    public function crear_usuarios(){
    include "../views/template_crear_usuarios.php";        
}    

//función que llama el template de Modificar Usuario//      
public function modificar_usuarios(){
    include "../views/template_modificar_usuarios.php";        
}   

//función que llama el template de Cambiar Clave Usuario//      
public function cambiar_clave_usuarios(){
    include "../views/template_cambiar_clave_usuarios.php";        
}   

}
