<?php
require_once "../models/crearCampanaModelo.php";
require_once "../models/loginModelo.php";
session_start();
//almacenamos la variable session en $id_usu_reg//
$id_usu_reg=$_SESSION['id_usuario'];

//almacenamos las variables POST//
$nom_campana=$_POST['nom_campana'];
$fecha_ini=$_POST['fecha_ini'];
$fecha_fin=$_POST['fecha_fin'];
$descrip_campana=$_POST['descrip_campana'];
$num_agentes=$_POST['num_agentes'];
$tipo_servicio=$_POST['tipo_servicio'];
$objetivo_campana=$_POST['objetivo_campana'];
$dias_seg_intento=$_POST["dias_seg_intento"];
$importancia=$_POST["importancia"];
$mensaje_camp=$_POST["mensaje_campana"];
$estado="1";

//almacenamos la hora actual//
$fechahora_reg=Date("d-m-Y H:i:s");

//instanciamos la clase y ejecutamos la funcion enviando las variables anteriores como parametros//
$ejecutar = new crearCampanaModelo();
$ejecutar-> crearCampanaModelo($nom_campana,$fecha_ini,$fecha_fin,$descrip_campana,$objetivo_campana,$num_agentes,$tipo_servicio,$id_usu_reg,$importancia,$dias_seg_intento,$mensaje_camp,$estado,$fechahora_reg);