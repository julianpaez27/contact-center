<?php


class loginModelo{
     function logear($usuario,$clave){
        require_once '../models/conexionModelo.php';
        $consulta ="SELECT * FROM contact_usuarios_v2 WHERE clave='$clave' AND nit_usuario='$usuario'";
        $ejecute=sqlsrv_query($conn,$consulta);

        if($ejecute){
            while ($row = sqlsrv_fetch_array($ejecute)){
            session_start();
            $_SESSION['id_usuario'] = $row['id_usuario'];
            $_SESSION['nom_usuario'] = $row['nom_usuario'];
            $_SESSION['ape_usuario'] = $row['ape_usuario'];
            header("location:../template/dashboard.php");
        }
        }else{
            echo "<script>
                        alert('Usuario y/o contraseña incorrectos');
                        window.location= '../index.php'
            </script>";
        
        }
    }
}
