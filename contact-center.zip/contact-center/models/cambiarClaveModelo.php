<?php
class cambiarClaveModelo{
    public function cambiarClaveModelo($clave1, $clave2, $id_usuario){

        if($clave1 == $clave2){
            require_once '../models/conexionModelo.php';
            $consulta ="UPDATE contact_usuarios_v2 SET clave='$clave1' where id_usuario='$id_usuario'";
            $ejecute=sqlsrv_query($conn,$consulta);
        
            if($ejecute){
                echo "<script>
                alert('Cambio de contraseña correcto!');
                window.location= '../template/cambiar_clave_usuarios.php'
            </script>";
            die( print_r( sqlsrv_errors(), true));
            }
        }
        else{
            echo "<script>
            alert('Las conrtaseñas no coinciden, por favor intenta de nuevo!');
            window.location= '../template/cambiar_clave_usuarios.php'
        </script>";
        die( print_r( sqlsrv_errors(), true));
        }
    }
}