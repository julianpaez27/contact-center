<?php

$SERVERNAME = "10.60.21.5";
$conectioninfo=array("Database"=>"Mayorautos_prueba", "UID"=>"sistemaweb","PWD"=>"s1st3m4w3b","CharacterSet"=>"UTF-8");
$conn= sqlsrv_connect($SERVERNAME,$conectioninfo);

        