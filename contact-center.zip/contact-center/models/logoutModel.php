<?php
class logoutModel{
public function logout(){
session_start();//se ejecuta el session_star(); para que sepa que se inicio una sesión//
session_destroy();//se ejecuta el session_destroy(); que destruye la sesión//
header ('location:../index.php');// con la función header se especifica con el location: el archivo al que retorna//
}
}
