<?php
class crearCampanaModelo{
    function crearCampanaModelo($nom_campana,$fecha_ini,$fecha_fin,$descrip_campana,$objetivo_campana,$num_agentes,$tipo_servicio,$id_usu_reg,$importancia,$dias_seg_intento,$mensaje_camp,$estado,$fechahora_reg){
        
    require '../models/conexionModelo.php';
    date_default_timezone_set('America/Bogota');

	//Si se presiona crear
	if (isset($_POST['btn_crear'])){

        $sql ="INSERT INTO contact_campanas_v2 (nombre_camp,fecha_ini_camp,fecha_fin_camp,descripcion_camp,objetivos_camp,num_agentes_camp,tipo_servicio_camp,id_usu_reg,orden_camp,dias_segun_camp,msg_camp,estado_campana,fechahora_reg) VALUES ('$nom_campana','$fecha_ini','$fecha_fin','$descrip_campana','$objetivo_campana','$num_agentes','$tipo_servicio','$id_usu_reg','$importancia','$dias_seg_intento','$mensaje_camp','$estado','$fechahora_reg')";

        $ejec=sqlsrv_query($conn, $sql);        

        if($ejec){
            echo "<script>
                        alert('Campaña creada con exito!');
                        window.location= '../template/crear_campana.php'
            </script>";
            die( print_r( sqlsrv_errors(), true));
    
        }else{
            echo "<script>
                        alert('Error al crear la campaña, intente de nuevo');
            </script>";
            die( print_r( sqlsrv_errors(), true));
   }    
  }
 }
}